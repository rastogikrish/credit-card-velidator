# Credit Card Validator
A simple C++ program I wrote in my first computing course @SFU which validates credit card numbers using Luhn's Algorithm.
